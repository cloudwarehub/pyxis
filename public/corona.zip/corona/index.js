var restify = require('restify');
var cmd = require('node-cmd');
var os = require('os');

/* 创建host, 与pyxis建立连接 */
ActionCable = require('actioncable');

var cable = ActionCable.createConsumer('ws://192.168.1.224:3000/cable');

cable.subscriptions.create('HostChannel', {
    // normal channel code goes here...
});

//服务端程序
var server = restify.createServer();
server.use(restify.acceptParser(server.acceptable));
server.use(restify.authorizationParser());
server.use(restify.dateParser());
server.use(restify.queryParser());
server.use(restify.jsonp());
server.use(restify.gzipResponse());
server.use(restify.bodyParser());

function step1(cmd) {
    return 'C:/cip-server.exe -cmd=' + cmd;
}

function str(username) {
    return
    'net user ' + username + 'p@ssw0rd /add' +
    'net localgroup "Remote Desktop Users" ' + username + ' /add' +
    'reg load HKU/' + username + ' C:/users/+' + username + '/NTUSER.DAT' +
    'cmdkey /generic:TERMSRV/localhost /user:' + username + ' /pass:p@ssw0rd' +
    'start /B mstsc /v:localhost';
}


cmd.get('C:\\Users\\beenquiver\\Desktop\\corona\\cmd.bat ' + 'cloud001', function(data) {
        console.log('the shell response is : ', data);
    }
);


